# Handoff: HIIT Timer App

## Overview
A mobile HIIT (High-Intensity Interval Training) timer app with four screens:
1. **Workout Screen** — active timer running a session
2. **Sessions List** — browse, select and manage saved sessions
3. **Edit Session** — create or edit a session's interval sequence
4. **Settings** — appearance, workout preferences, audio & haptics

The app supports two visual themes: **Tidal** (dark, deep teal) and **Daybreak** (light, warm paper). All screens are designed at **390 × 844 px** (iPhone 14 equivalent). The design should be adaptable across all iPhone sizes.

---

## About the Design Files
The files in this bundle are **high-fidelity design references built in HTML + React**. They are prototypes showing intended look, layout, and interactions — not production code to ship directly. The task is to **recreate these designs in your target codebase** using its established patterns and libraries (React Native, SwiftUI, Flutter, etc.).

**Fidelity: High-fidelity.** Colors, typography, spacing, and interactions are final. Implement pixel-close to the designs.

---

## Fonts

| Role | Family | Weights |
|---|---|---|
| UI / body | **Inter** | 400, 500, 600, 700, 800, 900 |
| Timers / numbers | **Chakra Petch** (monospace) | 500, 600, 700 |

Both available on Google Fonts.

---

## Design Tokens

### Color Themes

#### Tidal (Dark)
```
bg gradient:       #0b1d26 → #0e2832  (165deg, bg[1] → bg[0])
accent:            #3ad6c6
btnGlyph:          #06131a  (icon color on accent buttons)

text:              #eef6f7
subText:           rgba(255,255,255,0.72)
faintText:         rgba(255,255,255,0.44)
hairline:          rgba(255,255,255,0.10)
ghostBg:           rgba(255,255,255,0.05)
card:              rgba(255,255,255,0.05)
```

#### Daybreak (Light)
```
bg gradient:       #f3efe6 → #e7e1d4  (165deg)
accent:            #ff5a3d
btnGlyph:          #ffffff

text:              #16242b
subText:           rgba(20,32,38,0.62)
faintText:         rgba(20,32,38,0.45)
hairline:          rgba(20,32,38,0.13)
ghostBg:           rgba(20,32,38,0.05)
card:              rgba(255,255,255,0.66)
```

### Phase Colors

| Phase | Tidal | Daybreak | Label | Icon |
|---|---|---|---|---|
| warmup | `#5fd38a` | `#1f9d57` | WARM UP | sun |
| work | `#ff8a3d` | `#e0631a` | WORK | flame |
| blast | `#ff5a5f` | `#e23b40` | ALL OUT | bolt |
| rest | `#46a6ff` | `#1f7fd6` | RECOVER | pause (double bar) |
| cooldown | `#5fd38a` | `#1f9d57` | COOL DOWN | snowflake |

---

## Shared Components

### Ghost Circle Button
- Size: 36 × 36 px (nav/header) or 54 × 54 px (controls), border-radius: 50%
- Background: `ghostBg`, border: 1px solid `hairline`
- Icon color: `subText`
- Used for: back, close, reset, skip, gear/settings

### Play/Pause Button
- Size: 74 × 74 px, border-radius: 50%
- Background: radial gradient from `accent` (full) to `accent` at 60% opacity
- Box shadow: `0 12px 30px {accent}55`, inset `0 1px 1px rgba(255,255,255,0.45)`
- Icon color: `btnGlyph`
- Pause icon: two rounded rectangles (8×26 px, rx 2.6)
- Play icon: filled triangle

### Accent Circle Button (＋)
- Size: 36 × 36 px, border-radius: 50%
- Background: `accent`, icon color: `btnGlyph`
- Box shadow: `0 6px 18px {accent}55`

### Pill Badge
- Padding: 3px 9px, border-radius: 999
- Background: `{color}22`, border: 1px solid `{color}44`
- Font: 10.5px Inter 700, letter-spacing 0.1em, uppercase
- Used for category (accent color) and difficulty (phase-mapped color)

### Difficulty Colors
```
Easy:   #5fd38a
Medium: #ff8a3d
Hard:   #ff5a5f
```

### Phase Strip (mini timeline)
- Height: 8–10 px, gap: 2 px between segments
- Each segment: flex-width proportional to interval duration, border-radius: 4–5 px
- Color: phase color at 85% opacity
- Used in session cards and Edit Session preview

### Settings Toggle
- Size: 46 × 27 px, border-radius: 999
- **On**: bg `accent`, border `accent`, box-shadow `0 3px 10px {accent}55`, thumb slides right
- **Off**: bg `ghostBg`, border `hairline`, thumb sits left
- Thumb: 19 × 19 px circle, bg `btnGlyph` (on) / `subText` (off), shadow `0 1px 4px rgba(0,0,0,0.25)`
- Thumb transition: `left 0.18s cubic-bezier(.4,0,.2,1)`

### Settings Row
- Layout: `flex-row, space-between, align-center`, padding: 13px 16px
- Divider: 1px `hairline` bottom border (omit on last row)
- Label: 15px Inter 600 `text`
- Subtitle: 12px Inter 500 `faintText`, margin-top 2px
- Right slot: toggle, value text, or chevron

### Settings Section Group
- Section header: 11px Inter 700 uppercase, letter-spacing 0.12em, `faintText`, padding-left 4px, margin-bottom 8px
- Card: bg `card`, border 1px `hairline`, border-radius 18, overflow hidden

---

## Screen 1: Workout Timer (Hero Layout)

### Layout
Full-screen, `flex-column`, padding: 54px top, 20px sides, 24px bottom.
Background: theme `bg` gradient (165deg).

### Sections (top → bottom)
```
[Header]
[Phase center block]   — flex:1, centered
[Next up row]
[Timeline strip]
[Controls row]
```

### Header
- Left: label "INTERVAL SESSION" (10.5px Inter 700, letter-spacing 0.18em, uppercase, `faintText`) + title "Tabata Burnout" (18px Inter 700, `text`)
- Right: close button — 36×36 ghost circle, ✕ 14×14

### Phase Center Block
`flex-column, align-center, gap: 8px`, vertically centered.

1. **Phase icon badge**: 40×40 px, border-radius: 12 px, bg `{phaseColor}22`, border 1.5px `{phaseColor}55`. SVG icon 23×23 in phase color.
2. **Phase label**: 36px Inter 900, letter-spacing 0.01em, color `phaseColor`, text-shadow `0 0 30px {phaseColor}55`.
3. **Countdown clock**: Chakra Petch 700, 86px, line-height 1, tabular-nums, color `text`, text-shadow `0 0 34px {phaseColor}3a`. Format: `MM:SS`.
4. **Interval counter**: 13.5px Inter 700, `faintText`, letter-spacing 0.08em. "INTERVAL **N** OF 10" — N in `phaseColor`.
5. **Phase progress bar**: 100% width, max-width 240px, height 22px, border-radius 6, bg `hairline`. Fill depletes right→left; fill color `phaseColor`, box-shadow `0 0 12px {phaseColor}99`. Transition: `width 0.2s linear`.

### Next Up Row
`flex-row, align-center, justify-center, gap: 9px, padding: 8px 0`
- "NEXT" label: 11px Inter 700, letter-spacing 0.14em, `faintText`
- Arrow →, `faintText`
- Phase icon (15×15) + phase label: 14px Inter 800, letter-spacing 0.05em, `nextPhaseColor`
- If final interval: "FINISH" in current `phaseColor`

### Timeline Strip
Full width, `flex-column, gap: 8px, margin-bottom: 6px`.

**Bar** (height 22px, position relative):
- Segments: `flex-row, gap: 2px`. Width = `(duration / total) * 100%`, min-width 2px, border-radius 5.
  - Completed: `opacity: 0.28`
  - Active: `opacity: 1`, box-shadow `0 0 0 1.5px {color}, 0 0 12px {color}99`
  - Upcoming: `opacity: 0.5`
- **Playhead**: absolute, `left: {pct}%`, width 3px, top -4px, bottom -4px, margin-left -1.5px, border-radius 3, bg `text`, box-shadow `0 0 9px {text}`, `transition: left 0.25s linear`.
  - Circle cap: 12×12 px, border-radius 50%, top -6px, centered, same bg + shadow.

**Labels row** (below bar):
- Font: 12.5px Inter 700, letter-spacing 0.04em, color `subText`, tabular-nums
- Left: `{pct}%` (rounded integer)
- Right: `MM:SS left` (total time remaining)

### Controls Row
`flex-row, justify-center, gap: 22px, margin-top: 6px`
Order: [Reset 54px ghost] [Play/Pause 74px accent] [Skip 54px ghost]

---

## Screen 2: Sessions List

### Layout
Full-screen `flex-column`, padding: 54px top, 20px sides, 28px bottom. Scrollable.

### Header
`flex-row, space-between`
- Left: "CHOOSE" label (11px uppercase `faintText`) + "My Sessions" (22px Inter 800)
- Right: `flex-row, gap: 10px`
  - **Settings button** — 36×36 ghost circle, gear icon 17×17 `subText` → navigates to Settings screen
  - **Add button** — 36×36 accent circle, ＋ icon → navigates to Edit Session (isNew mode)

### Category Filter
`flex-row, gap: 8px, margin-bottom: 18px`
Tabs: All · HIIT · Express · Steady
- **Active**: bg `{accent}18`, border `accent`, color `accent`
- **Inactive**: bg `ghostBg`, border `hairline`, color `subText`
- Padding: 6px 14px, border-radius 999, font: 12px Inter 700, letter-spacing 0.06em

### Session Card
Border-radius: 20px, padding: 16px 16px 14px.
- **Default**: bg `card`, border 1.5px `hairline`
- **Selected**: bg `{accent}14`, border 1.5px `accent`, box-shadow `0 0 0 1px {accent}33`
- Transition: 0.2s

**Top row** (space-between):
- Left: name (16px Inter 800) + pill badges (gap 8px): category + difficulty
- Right: edit pencil — 34×34 ghost circle

**Phase strip**: height 9px, margin-top 10px

**Stats row** (gap 16px, margin-top 10px):
- Duration: Chakra Petch 14px 700 `text` + "total" 11px 600 `faintText`
- Count: Chakra Petch 14px 700 `text` + "intervals" 11px 600 `faintText`

**Start button** (selected only):
- Width 100%, padding 12px, border-radius 14, bg `accent`, color `btnGlyph`
- Font: 14px Inter 800, letter-spacing 0.06em, box-shadow `0 8px 22px {accent}55`
- Label: "START SESSION"

---

## Screen 3: Edit Session

### Layout
Full-screen `flex-column`, padding: 54px top, 20px sides, 28px bottom.
Intervals list: `flex: 1, min-height: 0, overflow-y: auto` — scrollable.
Phase picker: `flex-shrink: 0` — pinned below list.

### Header
`flex-row, space-between, margin-bottom: 24px`
- Left: back button (36×36 ghost, ‹ chevron) + label/title stack
  - Label: 11px Inter 700 uppercase, `faintText` — "Edit" or "Create"
  - Title: 20px Inter 800 — "Edit Session" or "New Session"
- Right: accent ＋ circle (36×36) — reveals phase picker

### Session Name Field
Label: "SESSION NAME" — 11px Inter 700 uppercase, `faintText`, margin-bottom 7px
Input: bg `card`, border-radius 14, padding 12px 16px
- Filled: border 1.5px `accent`, 16px Inter 700 `text`
- Empty: border 1.5px `hairline`, placeholder `faintText`

### Preview Strip
PhaseStrip, height 10px, radius 5. Updates live.

### Intervals Header Row
`flex-row, space-between, margin-top: 16px, margin-bottom: 10px`
- Left: "INTERVALS" — 11px Inter 700 uppercase, `faintText`
- Right: Chakra Petch 13px 600 `subText` — `"Xm · N blocks"`

### Interval Row
`flex-row, align-center, gap: 12px`, bg `card`, border 1px `hairline`, border-radius 14, padding 11px 14px.

Left → right:
1. Drag handle: 3 lines, 14×14, `faintText`
2. Phase dot: 10×10 circle, phase color
3. Phase name: 14px Inter 700 `text`, flex:1
4. Duration stepper: `−` (26×26 ghost) · Chakra Petch 15px 700 value · `+` (26×26 ghost). Step 5s, min 5s.
5. Delete: 28×28 ghost circle, ✕ 12×12

### Phase Picker (inline, below list)
Appears when ＋ is tapped. `flex-column, gap: 10px`, border-radius 16, border 1.5px `{accent}55`, bg `{accent}0e`, padding 14px.
- Header: "CHOOSE PHASE" (11px 700 uppercase `faintText`) + ✕ close
- Pills (flex-wrap, gap 8px): bg `{col}18`, border `{col}55`, color phase, 13px Inter 700
- On tap: appends interval (30s default), dismisses picker

---

## Screen 4: Settings

### Entry Point
Gear icon button (36×36 ghost circle) in the Sessions List header, left of the ＋ button.

### Layout
Full-screen `flex-column`, padding: 54px top, 20px sides, 28px bottom, `overflow-y: auto`.

### Header
`flex-row, space-between, margin-bottom: 28px`
- Left: back button (36×36 ghost, ‹) + label/title stack
  - Label: "PREFERENCES" — 11px Inter 700 uppercase, `faintText`
  - Title: "Settings" — 20px Inter 800
- Right: gear icon — 36×36 ghost circle (decorative, `faintText`)

### Appearance Section
Section header: "APPEARANCE"
Two theme cards side by side (`flex-row, gap: 10px`):

**Theme Card** (flex: 1):
- Border-radius: 16, border: 2px `hairline` (unselected) / 2px `accent` (selected)
- Selected shadow: `0 0 0 1px {accent}44, 0 6px 18px {accent}33`
- Transition: 0.2s

  **Gradient preview** (height 64px):
  - Background: the theme's own `bg` gradient
  - Bottom-left: accent dot (12×12, phase color glow) + 4 phase color dots (6×6, 70% opacity)

  **Label row** (padding 10px 12px 11px, bg `card`, border-top 1px `hairline`):
  - Theme name: 13px Inter 700 `text`
  - Theme note: 11px `faintText`
  - Checkmark circle (right): 20×20, filled `accent` + white ✓ tick when selected; empty `hairline` border when not

### Workout Section
Section header: "WORKOUT"

| Row | Label | Subtitle | Control |
|---|---|---|---|
| 1 | Congratulatory message | Full-screen celebration at workout end | Toggle (default: on) |
| 2 | Final countdown beep | Audio cue in last 3 seconds | Toggle (default: on) |
| 3 | Keep screen awake | Prevent display sleep during workout | Toggle (default: on) |

### Audio & Haptics Section
Section header: "AUDIO & HAPTICS"

| Row | Label | Subtitle | Control |
|---|---|---|---|
| 1 | Sound cues | Play tones on phase changes | Toggle (default: on) |
| 2 | Haptic feedback | Vibrate on interval transitions | Toggle (default: on) |

### About Section
Section header: "ABOUT"

| Row | Label | Right |
|---|---|---|
| 1 | Version | "1.0.0" in Chakra Petch 13px 600 `faintText` |
| 2 | Rate the app | › chevron |

---

## Interactions & Behavior

### Workout Timer
- Runs automatically on load; ticks every ~90ms
- Play/pause toggles clock; Reset → elapsed=0, paused; Skip → next interval boundary
- Clock loops when total duration reached (showcase mode)
- Phase color, icon, label, countdown, progress bar, and timeline all update reactively
- Progress bar depletes right→left (time remaining in current interval)
- Timeline playhead: `transition: left 0.25s linear`

### Sessions List
- Tap card → select (highlight + reveals START SESSION)
- Category tabs filter; "All" shows everything
- Edit pencil → Edit Session screen
- ＋ → Edit Session (isNew=true)
- Gear → Settings screen

### Edit Session
- ＋ reveals phase picker inline below list
- Tap phase pill → appends interval (30s), closes picker
- ✕ closes picker without adding
- Steppers adjust by 5s, floor 5s
- Drag handle (visual only in prototype — implement drag-to-reorder)
- Preview strip updates live

### Settings
- Theme cards: tapping selects that theme (updates checkmark + border); in production this persists and re-renders the whole app
- Toggles: tap to flip; transitions animate
- All state persists to local storage / user defaults in production

---

## Workout Data Model

```typescript
type PhaseType = 'warmup' | 'work' | 'blast' | 'rest' | 'cooldown';

interface Interval {
  type: PhaseType;
  dur: number; // seconds
}

interface Session {
  id: number;
  name: string;
  category: 'HIIT' | 'Express' | 'Steady';
  difficulty: 'Easy' | 'Medium' | 'Hard';
  intervals: Interval[];
}

interface AppSettings {
  theme: 'tidal' | 'daybreak';
  congratsMessage: boolean;
  countdownBeep: boolean;
  keepAwake: boolean;
  soundCues: boolean;
  hapticFeedback: boolean;
}
```

### Sample workout (Tabata Burnout) — 285 seconds total
```
warmup   45s
work     30s
rest     15s
blast    30s
rest     15s
work     30s
rest     15s
blast    30s
rest     15s
cooldown 60s
```

### deriveState(elapsed)
```typescript
function deriveState(elapsed: number, intervals: Interval[]) {
  let acc = 0;
  for (let i = 0; i < intervals.length; i++) {
    if (elapsed < acc + intervals[i].dur || i === intervals.length - 1) {
      return { idx: i, into: elapsed - acc, acc, cur: intervals[i] };
    }
    acc += intervals[i].dur;
  }
}
```

### Time formatting
```typescript
function tfmt(s: number): string {
  s = Math.max(0, Math.ceil(s));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}
```

---

## Design Reference Files

| File | Contents |
|---|---|
| `HIIT Timer - Explorations.html` | Live design canvas — all screens in both themes |
| `themes.js` | Color tokens for both themes |
| `themed-core.jsx` | Clock hook, deriveState, shared buttons + icons |
| `themed-layouts.jsx` | Workout timer screen (Hero layout + Timeline) |
| `sessions-screens.jsx` | Sessions List + Edit Session screens |
| `settings-screen.jsx` | Settings screen |

Open `HIIT Timer - Explorations.html` in a browser to see all screens running live.
