// Color schemes. Each theme carries bg, accent, semantic phase colors, and UI tokens.
(function () {
  const darkTokens = {
    text: '#eef6f7', subText: 'rgba(255,255,255,0.72)', faintText: 'rgba(255,255,255,0.44)',
    hairline: 'rgba(255,255,255,0.10)', ghostBg: 'rgba(255,255,255,0.05)', card: 'rgba(255,255,255,0.05)',
  };
  const lightTokens = {
    text: '#16242b', subText: 'rgba(20,32,38,0.62)', faintText: 'rgba(20,32,38,0.45)',
    hairline: 'rgba(20,32,38,0.13)', ghostBg: 'rgba(20,32,38,0.05)', card: 'rgba(255,255,255,0.66)',
  };
  const stdPhases = { warmup: '#5fd38a', work: '#ff8a3d', blast: '#ff5a5f', rest: '#46a6ff', cooldown: '#5fd38a' };

  window.THEMES = [
    {
      key: 'tidal', name: 'Tidal', note: 'Deep teal · calm',
      bg: ['#0b1d26', '#0e2832'], accent: '#3ad6c6', btnGlyph: '#06131a',
      ambient: false, phases: stdPhases, ...darkTokens,
    },
    {
      key: 'daybreak', name: 'Daybreak', note: 'Light · warm paper',
      bg: ['#f3efe6', '#e7e1d4'], accent: '#ff5a3d', btnGlyph: '#ffffff',
      ambient: false, phases: { warmup: '#1f9d57', work: '#e0631a', blast: '#e23b40', rest: '#1f7fd6', cooldown: '#1f9d57' }, ...lightTokens,
    },
  ];
})();
