// Sessions screens — SessionsList + EditSession — parameterised by theme.
// Same visual vocabulary as ThemedTimer: ghost surfaces, hairlines,
// Chakra Petch numbers, phase colour dots.

const SM_PHASES = [
  { type: 'warmup',   label: 'Warm Up',   short: 'WU', color: '#5fd38a' },
  { type: 'work',     label: 'Work',      short: 'WK', color: '#ff8a3d' },
  { type: 'blast',    label: 'All Out',   short: 'AO', color: '#ff5a5f' },
  { type: 'rest',     label: 'Recover',   short: 'RE', color: '#46a6ff' },
  { type: 'cooldown', label: 'Cool Down', short: 'CD', color: '#5fd38a' },
];

function phaseCol(type) {
  return (SM_PHASES.find(p => p.type === type) || SM_PHASES[0]).color;
}

// light/dark colour overrides for Daybreak
function resolvePhaseCol(theme, type) {
  if (theme.phases) return theme.phases[type];
  return phaseCol(type);
}

// mini phase strip — proportional coloured segments
function PhaseStrip({ intervals, theme, height = 8, radius = 4 }) {
  const total = intervals.reduce((a, b) => a + b.dur, 0) || 1;
  return (
    <div style={{ display: 'flex', gap: 2, width: '100%', height }}>
      {intervals.map((iv, i) => (
        <div key={i} style={{
          flex: iv.dur / total, minWidth: 3, height: '100%',
          borderRadius: radius,
          background: resolvePhaseCol(theme, iv.type),
          opacity: 0.85,
        }} />
      ))}
    </div>
  );
}

// pill badge
function Pill({ label, color, bg }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', padding: '3px 9px',
      borderRadius: 999, background: bg || `${color}22`,
      border: `1px solid ${color}44`,
      fontSize: 10.5, fontWeight: 700, letterSpacing: '0.1em',
      color: color, textTransform: 'uppercase', whiteSpace: 'nowrap',
    }}>{label}</span>
  );
}

// ── sample session data ─────────────────────────────────────────
const SESSIONS = [
  {
    id: 1, name: 'Tabata Burnout', category: 'HIIT',
    intervals: [
      { type: 'warmup', dur: 45 }, { type: 'work', dur: 30 }, { type: 'rest', dur: 15 },
      { type: 'blast', dur: 30 }, { type: 'rest', dur: 15 }, { type: 'work', dur: 30 },
      { type: 'rest', dur: 15 }, { type: 'blast', dur: 30 }, { type: 'rest', dur: 15 },
      { type: 'cooldown', dur: 60 },
    ],
    difficulty: 'Hard',
  },
  {
    id: 2, name: 'Quick Blast', category: 'Express',
    intervals: [
      { type: 'warmup', dur: 30 }, { type: 'work', dur: 20 }, { type: 'rest', dur: 10 },
      { type: 'work', dur: 20 }, { type: 'rest', dur: 10 }, { type: 'cooldown', dur: 30 },
    ],
    difficulty: 'Medium',
  },
  {
    id: 3, name: 'Endurance Run', category: 'Steady',
    intervals: [
      { type: 'warmup', dur: 60 }, { type: 'work', dur: 90 }, { type: 'rest', dur: 30 },
      { type: 'work', dur: 90 }, { type: 'rest', dur: 30 }, { type: 'work', dur: 90 },
      { type: 'cooldown', dur: 60 },
    ],
    difficulty: 'Easy',
  },
  {
    id: 4, name: 'Peak & Valley', category: 'HIIT',
    intervals: [
      { type: 'warmup', dur: 45 }, { type: 'work', dur: 40 }, { type: 'rest', dur: 20 },
      { type: 'blast', dur: 20 }, { type: 'rest', dur: 20 }, { type: 'work', dur: 40 },
      { type: 'rest', dur: 20 }, { type: 'cooldown', dur: 45 },
    ],
    difficulty: 'Hard',
  },
];

function totalDur(ivs) {
  const s = ivs.reduce((a, b) => a + b.dur, 0);
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return sec === 0 ? `${m}m` : `${m}m ${sec}s`;
}

const DIFF_COLOR = { Easy: '#5fd38a', Medium: '#ff8a3d', Hard: '#ff5a5f' };
const CATS = ['All', 'HIIT', 'Express', 'Steady'];

// ══════════════════════════════════════════════════════════════
// SCREEN 1 — Sessions List
// ══════════════════════════════════════════════════════════════
function SessionsList({ theme, activeId = 1 }) {
  const [cat, setCat] = React.useState('All');
  const [active, setActive] = React.useState(activeId);
  const filtered = cat === 'All' ? SESSIONS : SESSIONS.filter(s => s.category === cat);

  return (
    <div style={{
      width: '100%', height: '100%',
      background: `linear-gradient(165deg, ${theme.bg[1]} 0%, ${theme.bg[0]} 60%)`,
      display: 'flex', flexDirection: 'column',
      padding: '54px 20px 28px', boxSizing: 'border-box',
      fontFamily: "'Inter', sans-serif", color: theme.text, overflowY: 'auto',
    }}>
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: theme.faintText, fontWeight: 700 }}>Choose</div>
          <div style={{ fontSize: 22, fontWeight: 800, letterSpacing: '-0.01em' }}>My Sessions</div>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          {/* settings button */}
          <button style={{
            appearance: 'none', cursor: 'pointer', width: 36, height: 36, borderRadius: '50%',
            border: `1px solid ${theme.hairline}`, background: theme.ghostBg,
            color: theme.subText, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
          {/* add button */}
          <button style={{
            appearance: 'none', cursor: 'pointer', width: 36, height: 36, borderRadius: '50%',
            border: 'none', background: theme.accent, color: theme.btnGlyph,
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            boxShadow: `0 6px 18px ${theme.accent}55`,
          }}>
            <svg width="14" height="14" viewBox="0 0 14 14"><path d="M7 1v12M1 7h12" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"/></svg>
          </button>
        </div>
      </div>

      {/* category filter */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        {CATS.map(c => (
          <button key={c} onClick={() => setCat(c)} style={{
            appearance: 'none', cursor: 'pointer', padding: '6px 14px', borderRadius: 999,
            border: `1px solid ${cat === c ? theme.accent : theme.hairline}`,
            background: cat === c ? `${theme.accent}18` : theme.ghostBg,
            color: cat === c ? theme.accent : theme.subText,
            fontSize: 12, fontWeight: 700, letterSpacing: '0.06em',
          }}>{c}</button>
        ))}
      </div>

      {/* session cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {filtered.map(s => {
          const isActive = s.id === active;
          return (
            <div key={s.id} onClick={() => setActive(s.id)} style={{
              borderRadius: 20,
              background: isActive ? `${theme.accent}14` : theme.card,
              border: `1.5px solid ${isActive ? theme.accent : theme.hairline}`,
              padding: '16px 16px 14px',
              cursor: 'pointer', transition: 'border-color 0.2s, background 0.2s',
              boxShadow: isActive ? `0 0 0 1px ${theme.accent}33` : 'none',
            }}>
              {/* top row */}
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
                <div style={{ flex: 1, marginRight: 10 }}>
                  <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: '-0.01em', lineHeight: 1.2 }}>{s.name}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 5 }}>
                    <Pill label={s.category} color={theme.accent} />
                    <Pill label={s.difficulty} color={DIFF_COLOR[s.difficulty]} />
                  </div>
                </div>
                {/* edit button */}
                <button style={{
                  appearance: 'none', cursor: 'pointer', width: 34, height: 34,
                  borderRadius: '50%', border: `1px solid ${theme.hairline}`,
                  background: theme.ghostBg, color: theme.subText,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                }}>
                  <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M11.5 2.5a1.5 1.5 0 0 1 2.12 2.12L5 13.25 2 14l.75-3L11.5 2.5z" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </button>
              </div>

              {/* phase strip */}
              <PhaseStrip intervals={s.intervals} theme={theme} height={9} />

              {/* stats row */}
              <div style={{ display: 'flex', gap: 16, marginTop: 10 }}>
                <span style={{ fontSize: 11, color: theme.faintText, fontWeight: 600 }}>
                  <span style={{ fontFamily: "'Chakra Petch', monospace", fontSize: 14, fontWeight: 700, color: theme.text }}>{totalDur(s.intervals)}</span>
                  {' '}total
                </span>
                <span style={{ fontSize: 11, color: theme.faintText, fontWeight: 600 }}>
                  <span style={{ fontFamily: "'Chakra Petch', monospace", fontSize: 14, fontWeight: 700, color: theme.text }}>{s.intervals.length}</span>
                  {' '}intervals
                </span>
              </div>

              {/* start button — only on active card */}
              {isActive && (
                <div style={{ marginTop: 14 }}>
                  <button style={{
                    appearance: 'none', cursor: 'pointer', width: '100%', padding: '12px 0',
                    borderRadius: 14, border: 'none',
                    background: theme.accent, color: theme.btnGlyph,
                    fontSize: 14, fontWeight: 800, letterSpacing: '0.06em',
                    boxShadow: `0 8px 22px ${theme.accent}55`,
                  }}>START SESSION</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// SCREEN 2 — Edit Session
// ══════════════════════════════════════════════════════════════
const EDIT_INTERVALS = [
  { type: 'warmup', dur: 45 }, { type: 'work', dur: 30 }, { type: 'rest', dur: 15 },
  { type: 'blast', dur: 30 }, { type: 'rest', dur: 15 }, { type: 'work', dur: 30 },
  { type: 'rest', dur: 15 }, { type: 'cooldown', dur: 60 },
];

function TypeDot({ color }) {
  return <span style={{ width: 10, height: 10, borderRadius: '50%', background: color, display: 'inline-block', flexShrink: 0 }} />;
}

function EditSession({ theme, isNew = false }) {
  const [name, setName] = React.useState(isNew ? '' : 'Tabata Burnout');
  const [ivs, setIvs] = React.useState(EDIT_INTERVALS);
  const [picking, setPicking] = React.useState(false);

  const removeIv = (i) => setIvs(ivs.filter((_, j) => j !== i));
  const changeDur = (i, delta) => setIvs(ivs.map((iv, j) => j === i ? { ...iv, dur: Math.max(5, iv.dur + delta) } : iv));
  const addIv = (type) => { setIvs([...ivs, { type, dur: 30 }]); setPicking(false); };

  return (
    <div style={{
      width: '100%', height: '100%',
      background: `linear-gradient(165deg, ${theme.bg[1]} 0%, ${theme.bg[0]} 60%)`,
      display: 'flex', flexDirection: 'column',
      padding: '54px 20px 28px', boxSizing: 'border-box',
      fontFamily: "'Inter', sans-serif", color: theme.text,
    }}>
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button style={{
            appearance: 'none', cursor: 'pointer', width: 36, height: 36, borderRadius: '50%',
            border: `1px solid ${theme.hairline}`, background: theme.ghostBg,
            color: theme.subText, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 13L5 8l5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <div>
            <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: theme.faintText, fontWeight: 700 }}>{isNew ? 'Create' : 'Edit'}</div>
            <div style={{ fontSize: 20, fontWeight: 800, letterSpacing: '-0.01em' }}>{isNew ? 'New Session' : 'Edit Session'}</div>
          </div>
        </div>
        <button onClick={() => setPicking(true)} style={{
          appearance: 'none', cursor: 'pointer', width: 36, height: 36, borderRadius: '50%',
          border: 'none', background: theme.accent, color: theme.btnGlyph,
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          boxShadow: `0 6px 18px ${theme.accent}55`,
        }}>
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M7 1v12M1 7h12" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"/></svg>
        </button>
      </div>

      {/* session name field */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: theme.faintText, marginBottom: 7 }}>Session Name</div>
        <div style={{
          background: theme.card, border: `1.5px solid ${name ? theme.accent : theme.hairline}`,
          borderRadius: 14, padding: '12px 16px',
          fontFamily: "'Inter', sans-serif", fontSize: 16, fontWeight: 700,
          color: name ? theme.text : theme.faintText, letterSpacing: '-0.01em',
        }}>{name || 'e.g. Morning Blast'}</div>
      </div>

      {/* preview strip */}
      <PhaseStrip intervals={ivs} theme={theme} height={10} radius={5} />

      {/* intervals label + total */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 16, marginBottom: 10 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: theme.faintText }}>Intervals</div>
        <div style={{ fontFamily: "'Chakra Petch', monospace", fontSize: 13, fontWeight: 600, color: theme.subText }}>{totalDur(ivs)} · {ivs.length} blocks</div>
      </div>

      {/* interval rows — scrollable, never covers the add button */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, overflowY: 'auto', flex: 1, minHeight: 0 }}>
        {ivs.map((iv, i) => {
          const col = resolvePhaseCol(theme, iv.type);
          const meta = SM_PHASES.find(p => p.type === iv.type);
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              background: theme.card, border: `1px solid ${theme.hairline}`,
              borderRadius: 14, padding: '11px 14px',
            }}>
              {/* drag handle */}
              <svg width="14" height="14" viewBox="0 0 14 14" style={{ color: theme.faintText, flexShrink: 0 }}>
                <rect y="2" width="14" height="2" rx="1" fill="currentColor"/>
                <rect y="6" width="14" height="2" rx="1" fill="currentColor"/>
                <rect y="10" width="14" height="2" rx="1" fill="currentColor"/>
              </svg>
              <TypeDot color={col} />
              <span style={{ flex: 1, fontSize: 14, fontWeight: 700, color: theme.text }}>{meta?.label}</span>
              {/* duration stepper */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <button onClick={() => changeDur(i, -5)} style={{ appearance: 'none', cursor: 'pointer', width: 26, height: 26, borderRadius: '50%', border: `1px solid ${theme.hairline}`, background: theme.ghostBg, color: theme.subText, fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>−</button>
                <span style={{ fontFamily: "'Chakra Petch', monospace", fontSize: 15, fontWeight: 700, color: theme.text, minWidth: 36, textAlign: 'center' }}>{iv.dur}s</span>
                <button onClick={() => changeDur(i, 5)} style={{ appearance: 'none', cursor: 'pointer', width: 26, height: 26, borderRadius: '50%', border: `1px solid ${theme.hairline}`, background: theme.ghostBg, color: theme.subText, fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
              </div>
              {/* delete */}
              <button onClick={() => removeIv(i)} style={{ appearance: 'none', cursor: 'pointer', width: 28, height: 28, borderRadius: '50%', border: `1px solid ${theme.hairline}`, background: theme.ghostBg, color: theme.faintText, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 2l8 8M10 2L2 10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
              </button>
            </div>
          );
        })}
      </div>

      {/* phase picker — appears below list when + is tapped */}
      {picking && (
        <div style={{
          marginTop: 10, flexShrink: 0,
          borderRadius: 16, border: `1.5px solid ${theme.accent}55`,
          background: `${theme.accent}0e`, padding: '14px 14px 12px',
          display: 'flex', flexDirection: 'column', gap: 10,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: theme.faintText }}>Choose phase</span>
            <button onClick={() => setPicking(false)} style={{ appearance: 'none', cursor: 'pointer', background: 'none', border: 'none', color: theme.faintText, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 4 }}>
              <svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 2l8 8M10 2L2 10" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
            </button>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {SM_PHASES.map(p => {
              const col = resolvePhaseCol(theme, p.type);
              return (
                <button key={p.type} onClick={() => addIv(p.type)} style={{
                  appearance: 'none', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: 7,
                  padding: '8px 14px', borderRadius: 999,
                  background: `${col}18`, border: `1.5px solid ${col}55`,
                  color: col, fontSize: 13, fontWeight: 700,
                  letterSpacing: '0.04em', whiteSpace: 'nowrap',
                  transition: 'background 0.12s',
                }}>
                  <span style={{ width: 8, height: 8, borderRadius: '50%', background: col, flexShrink: 0 }} />
                  {p.label}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

window.SessionsList = SessionsList;
window.EditSession = EditSession;
