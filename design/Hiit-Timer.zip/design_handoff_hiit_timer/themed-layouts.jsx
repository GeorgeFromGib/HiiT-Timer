// Three layouts + theme list + ThemedTimer wrapper.
const H = window.HIIT;

// ════════ LAYOUT A · HERO (word-first) ════════
function LayoutHero({ theme, elapsed, running, setRunning, setElapsed }) {
  const { idx, into, cur } = H.deriveState(elapsed);
  const meta = H.PHASE_META[cur.type];
  const col = H.phaseColor(theme, cur.type);
  const next = H.TWORKOUT[idx + 1];
  const nMeta = next ? H.PHASE_META[next.type] : null;
  const nCol = next ? H.phaseColor(theme, next.type) : col;
  const intervals = H.TWORKOUT.map((iv) => ({ ...iv, color: H.phaseColor(theme, iv.type) }));

  return (
    <>
      <H.Header theme={theme} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <span style={{ display: 'inline-flex', width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', background: `${col}22`, border: `1.5px solid ${col}55` }}><H.TIcon name={meta.icon} color={col} size={23} /></span>
          <span style={{ fontSize: 36, fontWeight: 900, letterSpacing: '0.01em', color: col, textShadow: `0 0 30px ${col}55`, whiteSpace: 'nowrap', lineHeight: 1 }}>{meta.label}</span>
        </div>
        <span style={{ fontFamily: "'Chakra Petch', monospace", fontWeight: 700, fontSize: 86, lineHeight: 1, fontVariantNumeric: 'tabular-nums', color: theme.text, textShadow: `0 0 34px ${col}3a` }}>{H.tfmt(cur.dur - into)}</span>
        <span style={{ fontSize: 13.5, fontWeight: 700, color: theme.faintText, letterSpacing: '0.08em', marginTop: 2 }}>INTERVAL <span style={{ color: col }}>{idx + 1}</span> OF {H.TWORKOUT.length}</span>
        {/* phase-progress bar — same thickness as bottom timeline, depletes with time left in this zone */}
        <div style={{ width: '100%', maxWidth: 240, height: 22, borderRadius: 6, background: theme.hairline, overflow: 'hidden', marginTop: 18, display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ height: '100%', width: `${Math.max(0, ((cur.dur - into) / cur.dur) * 100)}%`, background: col, borderRadius: 6, boxShadow: `0 0 12px ${col}99`, transition: 'width 0.2s linear' }} />
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9, padding: '8px 0' }}>
        <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', color: theme.faintText }}>NEXT</span>
        <svg width="15" height="13" viewBox="0 0 16 14" style={{ color: theme.faintText }}><path d="M1 7h12M9 2l5 5-5 5" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
        {nMeta ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}><H.TIcon name={nMeta.icon} color={nCol} size={15} /><span style={{ fontSize: 14, fontWeight: 800, letterSpacing: '0.05em', color: nCol, whiteSpace: 'nowrap' }}>{nMeta.label}</span></span>
               : <span style={{ fontSize: 14, fontWeight: 800, color: col }}>FINISH</span>}
      </div>
      <Timeline theme={theme} intervals={intervals} elapsed={elapsed} idx={idx} />
      <H.Controls theme={theme} running={running} setRunning={setRunning} setElapsed={setElapsed} />
    </>
  );
}

// ════════ LAYOUT B · RING (segmented arc, matches reference) ════════
function LayoutRing({ theme, elapsed, running, setRunning, setElapsed }) {
  const { idx, into, cur } = H.deriveState(elapsed);
  const meta = H.PHASE_META[cur.type];
  const col = H.phaseColor(theme, cur.type);
  const intervals = H.TWORKOUT.map((iv) => ({ ...iv, color: H.phaseColor(theme, iv.type) }));
  const Stat = ({ label, value, accent }) => (
    <div style={{ flex: 1, background: theme.card, border: `1px solid ${theme.hairline}`, borderRadius: 16, padding: '13px 15px', display: 'flex', flexDirection: 'column', gap: 5 }}>
      <span style={{ fontSize: 10.5, letterSpacing: '0.13em', textTransform: 'uppercase', fontWeight: 700, color: accent || theme.faintText }}>{label}</span>
      <span style={{ fontFamily: "'Chakra Petch', monospace", fontWeight: 600, fontSize: 26, color: theme.text, fontVariantNumeric: 'tabular-nums' }}>{value}</span>
    </div>
  );
  return (
    <>
      <H.Header theme={theme} />
      <div style={{ display: 'flex', gap: 11, marginTop: 16 }}>
        <Stat label="Remaining" value={H.tfmt(H.TTOTAL - elapsed)} />
        <Stat label="Completed" value={H.tfmt(elapsed)} accent={theme.accent} />
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', marginTop: 6 }}>
        <window.SegmentedRing size={258} stroke={14} intervals={intervals} elapsed={elapsed} total={H.TTOTAL} />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '4px 13px', borderRadius: 999, background: `${col}1f`, border: `1px solid ${col}40` }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: col }} />
            <span style={{ fontSize: 12.5, fontWeight: 700, letterSpacing: '0.08em', color: col }}>{meta.label}</span>
          </span>
          <span style={{ fontFamily: "'Chakra Petch', monospace", fontWeight: 700, fontSize: 60, lineHeight: 1, fontVariantNumeric: 'tabular-nums', color: theme.text }}>{H.tfmt(cur.dur - into)}</span>
          <span style={{ fontSize: 13, fontWeight: 600, color: theme.faintText, letterSpacing: '0.05em' }}><span style={{ color: col }}>{idx + 1}</span> / {H.TWORKOUT.length}</span>
        </div>
      </div>
      <H.Controls theme={theme} running={running} setRunning={setRunning} setElapsed={setElapsed} />
    </>
  );
}

// ════════ LAYOUT C · STACK (big bars, list-forward) ════════
function LayoutStack({ theme, elapsed, running, setRunning, setElapsed }) {
  const { idx, into, cur } = H.deriveState(elapsed);
  const meta = H.PHASE_META[cur.type];
  const col = H.phaseColor(theme, cur.type);
  const pct = (into / cur.dur) * 100;
  return (
    <>
      <H.Header theme={theme} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 18 }}>
        {/* big phase card */}
        <div style={{ borderRadius: 24, padding: '22px 22px 20px', background: `linear-gradient(160deg, ${col}26, ${col}10)`, border: `1.5px solid ${col}44`, position: 'relative', overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <H.TIcon name={meta.icon} color={col} size={22} />
            <span style={{ fontSize: 22, fontWeight: 900, letterSpacing: '0.04em', color: col }}>{meta.label}</span>
            <span style={{ marginLeft: 'auto', fontSize: 12, fontWeight: 700, color: theme.faintText, letterSpacing: '0.08em' }}>{idx + 1}/{H.TWORKOUT.length}</span>
          </div>
          <span style={{ display: 'block', fontFamily: "'Chakra Petch', monospace", fontWeight: 700, fontSize: 74, lineHeight: 1, color: theme.text, fontVariantNumeric: 'tabular-nums', marginTop: 8 }}>{H.tfmt(cur.dur - into)}</span>
          <div style={{ height: 7, borderRadius: 5, background: theme.hairline, marginTop: 16, overflow: 'hidden' }}>
            <div style={{ height: '100%', width: `${pct}%`, background: col, borderRadius: 5, transition: 'width 0.2s linear' }} />
          </div>
        </div>
        {/* up next list */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', color: theme.faintText, paddingLeft: 2 }}>COMING UP</span>
          {H.TWORKOUT.slice(idx + 1, idx + 4).map((iv, i) => {
            const c = H.phaseColor(theme, iv.type); const m = H.PHASE_META[iv.type];
            return (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '11px 14px', borderRadius: 14, background: theme.card, border: `1px solid ${theme.hairline}` }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: c, flexShrink: 0 }} />
                <span style={{ fontSize: 14, fontWeight: 700, color: theme.text, letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>{m.label}</span>
                <span style={{ marginLeft: 'auto', fontFamily: "'Chakra Petch', monospace", fontSize: 15, fontWeight: 600, color: theme.subText }}>{H.tfmt(iv.dur)}</span>
              </div>
            );
          })}
          {idx >= H.TWORKOUT.length - 1 && <div style={{ padding: '11px 14px', borderRadius: 14, background: theme.card, border: `1px solid ${theme.hairline}`, fontSize: 14, fontWeight: 700, color: col }}>Finish line 🏁</div>}
        </div>
      </div>
      <H.Controls theme={theme} running={running} setRunning={setRunning} setElapsed={setElapsed} />
    </>
  );
}

// shared timeline strip used by Hero
function Timeline({ theme, intervals, elapsed, idx, gap = 2 }) {
  const pct = (Math.min(elapsed, H.TTOTAL) / H.TTOTAL) * 100;
  return (
    <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 6 }}>
      <div style={{ position: 'relative', width: '100%', height: 22 }}>
        <div style={{ display: 'flex', gap, width: '100%', height: '100%' }}>
          {intervals.map((iv, i) => (
            <div key={i} style={{ flexBasis: `${(iv.dur / H.TTOTAL) * 100}%`, minWidth: 2, height: '100%', borderRadius: 5, background: iv.color, opacity: i < idx ? 0.28 : i === idx ? 1 : 0.5, boxShadow: i === idx ? `0 0 0 1.5px ${iv.color}, 0 0 12px ${iv.color}99` : 'none', transition: 'opacity 0.3s' }} />
          ))}
        </div>
        <div style={{ position: 'absolute', top: -4, bottom: -4, left: `${pct}%`, width: 3, marginLeft: -1.5, borderRadius: 3, background: theme.text, boxShadow: `0 0 9px ${theme.text}`, transition: 'left 0.25s linear' }}>
          <div style={{ position: 'absolute', top: -6, left: '50%', transform: 'translateX(-50%)', width: 12, height: 12, borderRadius: '50%', background: theme.text, boxShadow: `0 0 9px ${theme.text}` }} />
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12.5, fontWeight: 700, letterSpacing: '0.04em', color: theme.subText, fontVariantNumeric: 'tabular-nums' }}>
        <span>{Math.round(pct)}%</span>
        <span>{H.tfmt(Math.max(0, H.TTOTAL - elapsed))} left</span>
      </div>
    </div>
  );
}

const LAYOUTS = { hero: LayoutHero, ring: LayoutRing, stack: LayoutStack };

function ThemedTimer({ theme, layout = 'hero', start = 0, autoplay = true }) {
  const [elapsed, running, setRunning, setElapsed] = H.useClock(start, autoplay);
  const { cur } = H.deriveState(elapsed);
  const col = H.phaseColor(theme, cur.type);
  const L = LAYOUTS[layout];
  const tintBg = theme.ambient
    ? `radial-gradient(130% 80% at 50% -10%, ${col}24 0%, ${theme.bg[1]} 38%, ${theme.bg[0]} 100%)`
    : `linear-gradient(165deg, ${theme.bg[1]} 0%, ${theme.bg[0]} 60%)`;
  return (
    <div style={{ width: '100%', height: '100%', background: tintBg, transition: 'background 0.6s ease', display: 'flex', flexDirection: 'column', padding: '54px 20px 24px', boxSizing: 'border-box', fontFamily: "'Inter', sans-serif", color: theme.text }}>
      <L theme={theme} elapsed={elapsed} running={running} setRunning={setRunning} setElapsed={setElapsed} />
    </div>
  );
}

window.ThemedTimer = ThemedTimer;
