// SegmentedRing — proportional colored arcs around a circle with a moving handle.
// Each interval becomes an arc sized to its duration; the handle marks live progress.

function polar(cx, cy, r, deg) {
  const a = (deg - 90) * Math.PI / 180; // 0deg = 12 o'clock
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
}

// SVG arc path between two angles (degrees, clockwise)
function arcPath(cx, cy, r, startDeg, endDeg) {
  const s = polar(cx, cy, r, endDeg);
  const e = polar(cx, cy, r, startDeg);
  const large = endDeg - startDeg <= 180 ? 0 : 1;
  return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 0 ${e.x} ${e.y}`;
}

function SegmentedRing({
  size = 300,
  stroke = 14,
  intervals = [],      // [{ dur, color }]
  elapsed = 0,         // seconds into the whole workout
  total = 1,
  gapDeg = 2.4,
}) {
  const cx = size / 2;
  const cy = size / 2;
  const r = (size - stroke) / 2 - 6;

  // build segment angle ranges
  let acc = 0;
  const segs = intervals.map((iv) => {
    const startFrac = acc / total;
    acc += iv.dur;
    const endFrac = acc / total;
    return {
      ...iv,
      start: startFrac * 360,
      end: endFrac * 360,
    };
  });

  const progressDeg = (Math.min(elapsed, total) / total) * 360;
  const handle = polar(cx, cy, r, progressDeg);

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display: 'block', overflow: 'visible' }}>
      <defs>
        <filter id="ringGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3" result="b" />
          <feMerge>
            <feMergeNode in="b" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* faint full track */}
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth={stroke} />

      {segs.map((s, i) => {
        const a0 = s.start + gapDeg / 2;
        const a1 = s.end - gapDeg / 2;
        if (a1 <= a0) return null;
        // dim segments that are fully in the past? keep them lit but slightly faded once done
        const done = elapsed >= (s.end / 360) * total - 0.001;
        const active = elapsed >= (s.start / 360) * total && !done;
        return (
          <path
            key={i}
            d={arcPath(cx, cy, r, a0, a1)}
            fill="none"
            stroke={s.color}
            strokeWidth={stroke}
            strokeLinecap="round"
            opacity={done ? 0.32 : 1}
            style={{
              transition: 'opacity 0.4s ease',
              filter: active ? 'url(#ringGlow)' : 'none',
            }}
          />
        );
      })}

      {/* moving handle */}
      <g style={{ transition: 'transform 0.25s linear' }} transform={`translate(${handle.x} ${handle.y})`}>
        <circle r={stroke / 2 + 6} fill="#0c1f28" />
        <circle r={stroke / 2 + 2.5} fill="#fff" />
        <circle r={stroke / 2 - 2} fill="#0c1f28" />
      </g>
    </svg>
  );
}

window.SegmentedRing = SegmentedRing;
