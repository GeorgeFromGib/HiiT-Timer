// SessionTimeline — the "you are here" whole-workout bar.
// Proportional segments per phase + a sweeping marker. Shows where you are and what's next.

function SessionTimeline({ intervals = [], elapsed = 0, total = 1, currentIdx = 0, gap = 2 }) {
  const pct = (Math.min(elapsed, total) / total) * 100;

  return (
    <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 9 }}>
      {/* the bar */}
      <div style={{ position: 'relative', width: '100%', height: 26 }}>
        <div style={{ display: 'flex', gap, width: '100%', height: '100%' }}>
          {intervals.map((iv, i) => {
            const w = (iv.dur / total) * 100;
            const done = i < currentIdx;
            const active = i === currentIdx;
            return (
              <div key={i} style={{
                flexBasis: `${w}%`, minWidth: 2, height: '100%',
                borderRadius: 5,
                background: iv.color,
                opacity: done ? 0.28 : active ? 1 : 0.5,
                boxShadow: active ? `0 0 0 1.5px ${iv.color}, 0 0 14px ${iv.color}99` : 'none',
                transition: 'opacity 0.3s ease, box-shadow 0.3s ease',
              }} />
            );
          })}
        </div>
        {/* sweeping marker */}
        <div style={{
          position: 'absolute', top: -5, bottom: -5, left: `${pct}%`,
          width: 3, marginLeft: -1.5, borderRadius: 3,
          background: '#fff', boxShadow: '0 0 10px rgba(255,255,255,0.9)',
          transition: 'left 0.25s linear',
        }}>
          <div style={{
            position: 'absolute', top: -7, left: '50%', transform: 'translateX(-50%)',
            width: 13, height: 13, borderRadius: '50%', background: '#fff',
            boxShadow: '0 0 10px rgba(255,255,255,0.9)',
          }} />
        </div>
      </div>


    </div>
  );
}

window.SessionTimeline = SessionTimeline;
