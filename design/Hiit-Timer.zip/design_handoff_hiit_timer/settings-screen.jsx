// Settings screen — parameterised by theme.
// Follows same visual vocabulary as sessions-screens.jsx

// ── Toggle ──────────────────────────────────────────────────────
function SettingsToggle({ value, onChange, theme }) {
  return (
    <div
      onClick={() => onChange(!value)}
      style={{
        width: 46, height: 27, borderRadius: 999, cursor: 'pointer', flexShrink: 0,
        background: value ? theme.accent : theme.ghostBg,
        border: `1.5px solid ${value ? theme.accent : theme.hairline}`,
        position: 'relative', transition: 'background 0.2s, border-color 0.2s',
        boxShadow: value ? `0 3px 10px ${theme.accent}55` : 'none',
      }}
    >
      <div style={{
        position: 'absolute', top: 2, left: value ? 21 : 2,
        width: 19, height: 19, borderRadius: '50%',
        background: value ? theme.btnGlyph : theme.subText,
        boxShadow: '0 1px 4px rgba(0,0,0,0.25)',
        transition: 'left 0.18s cubic-bezier(.4,0,.2,1)',
      }} />
    </div>
  );
}

// ── Settings Row ────────────────────────────────────────────────
function SRow({ label, sub, right, last, theme }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '13px 16px',
      borderBottom: last ? 'none' : `1px solid ${theme.hairline}`,
    }}>
      <div>
        <div style={{ fontSize: 15, fontWeight: 600, color: theme.text, lineHeight: 1.3 }}>{label}</div>
        {sub && <div style={{ fontSize: 12, color: theme.faintText, fontWeight: 500, marginTop: 2 }}>{sub}</div>}
      </div>
      {right}
    </div>
  );
}

// ── Section group ───────────────────────────────────────────────
function SSection({ title, children, theme }) {
  return (
    <div style={{ marginBottom: 24 }}>
      <div style={{
        fontSize: 11, fontWeight: 700, letterSpacing: '0.12em',
        textTransform: 'uppercase', color: theme.faintText,
        marginBottom: 8, paddingLeft: 4,
      }}>{title}</div>
      <div style={{
        background: theme.card,
        border: `1px solid ${theme.hairline}`,
        borderRadius: 18, overflow: 'hidden',
      }}>
        {children}
      </div>
    </div>
  );
}

// ── Theme Card ──────────────────────────────────────────────────
function ThemeCard({ th, selected, onSelect, currentTheme }) {
  const dark = th.key !== 'daybreak';
  return (
    <div
      onClick={() => onSelect(th.key)}
      style={{
        flex: 1, borderRadius: 16, overflow: 'hidden', cursor: 'pointer',
        border: `2px solid ${selected ? currentTheme.accent : currentTheme.hairline}`,
        boxShadow: selected ? `0 0 0 1px ${currentTheme.accent}44, 0 6px 18px ${currentTheme.accent}33` : 'none',
        transition: 'border-color 0.2s, box-shadow 0.2s',
      }}
    >
      {/* gradient preview */}
      <div style={{
        height: 64,
        background: `linear-gradient(165deg, ${th.bg[1]} 0%, ${th.bg[0]} 100%)`,
        display: 'flex', alignItems: 'flex-end', padding: '0 12px 10px',
        gap: 5,
      }}>
        {/* accent dot */}
        <div style={{
          width: 12, height: 12, borderRadius: '50%', background: th.accent,
          boxShadow: `0 0 8px ${th.accent}99`,
        }} />
        {/* mini phase dots */}
        {Object.values(th.phases).slice(0, 4).map((c, i) => (
          <div key={i} style={{ width: 6, height: 6, borderRadius: '50%', background: c, opacity: 0.7 }} />
        ))}
      </div>
      {/* label row */}
      <div style={{
        padding: '10px 12px 11px',
        background: currentTheme.card,
        borderTop: `1px solid ${currentTheme.hairline}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, color: currentTheme.text }}>{th.name}</div>
          <div style={{ fontSize: 11, color: currentTheme.faintText, marginTop: 1 }}>{th.note}</div>
        </div>
        {/* checkmark */}
        <div style={{
          width: 20, height: 20, borderRadius: '50%',
          background: selected ? currentTheme.accent : 'transparent',
          border: `1.5px solid ${selected ? currentTheme.accent : currentTheme.hairline}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transition: 'background 0.2s, border-color 0.2s',
          flexShrink: 0,
        }}>
          {selected && (
            <svg width="10" height="10" viewBox="0 0 10 10">
              <path d="M2 5.5l2.2 2.2L8 3" stroke={currentTheme.btnGlyph} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
            </svg>
          )}
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// SETTINGS SCREEN
// ══════════════════════════════════════════════════════════════
function SettingsScreen({ theme }) {
  const allThemes = window.THEMES;

  const [selectedTheme, setSelectedTheme] = React.useState(theme.key);

  // Workout toggles
  const [congrats,    setCongrats]    = React.useState(true);
  const [countdown,   setCountdown]   = React.useState(true);
  const [keepAwake,   setKeepAwake]   = React.useState(true);

  // Audio toggles
  const [soundCues,   setSoundCues]   = React.useState(true);
  const [haptics,     setHaptics]     = React.useState(true);

  return (
    <div style={{
      width: '100%', height: '100%',
      background: `linear-gradient(165deg, ${theme.bg[1]} 0%, ${theme.bg[0]} 60%)`,
      display: 'flex', flexDirection: 'column',
      padding: '54px 20px 28px', boxSizing: 'border-box',
      fontFamily: "'Inter', sans-serif", color: theme.text,
      overflowY: 'auto',
    }}>

      {/* ── Header ── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button style={{
            appearance: 'none', cursor: 'pointer', width: 36, height: 36, borderRadius: '50%',
            border: `1px solid ${theme.hairline}`, background: theme.ghostBg,
            color: theme.subText, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M10 13L5 8l5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <div>
            <div style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: theme.faintText, fontWeight: 700 }}>Preferences</div>
            <div style={{ fontSize: 20, fontWeight: 800, letterSpacing: '-0.01em' }}>Settings</div>
          </div>
        </div>
        {/* gear icon (decorative) */}
        <div style={{
          width: 36, height: 36, borderRadius: '50%',
          background: theme.ghostBg, border: `1px solid ${theme.hairline}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: theme.faintText,
        }}>
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="3"/>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
          </svg>
        </div>
      </div>

      {/* ── Appearance ── */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: theme.faintText, marginBottom: 10, paddingLeft: 4 }}>
          Appearance
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          {allThemes.map(th => (
            <ThemeCard
              key={th.key}
              th={th}
              selected={selectedTheme === th.key}
              onSelect={setSelectedTheme}
              currentTheme={theme}
            />
          ))}
        </div>
      </div>

      {/* ── Workout ── */}
      <SSection title="Workout" theme={theme}>
        <SRow theme={theme} label="Congratulatory message" sub="Full-screen celebration at workout end"
          right={<SettingsToggle value={congrats} onChange={setCongrats} theme={theme} />} />
        <SRow theme={theme} label="Final countdown beep" sub="Audio cue in last 3 seconds"
          right={<SettingsToggle value={countdown} onChange={setCountdown} theme={theme} />} />
        <SRow theme={theme} label="Keep screen awake" sub="Prevent display sleep during workout"
          right={<SettingsToggle value={keepAwake} onChange={setKeepAwake} theme={theme} />} last />
      </SSection>

      {/* ── Audio & Haptics ── */}
      <SSection title="Audio & Haptics" theme={theme}>
        <SRow theme={theme} label="Sound cues" sub="Play tones on phase changes"
          right={<SettingsToggle value={soundCues} onChange={setSoundCues} theme={theme} />} />
        <SRow theme={theme} label="Haptic feedback" sub="Vibrate on interval transitions"
          right={<SettingsToggle value={haptics} onChange={setHaptics} theme={theme} />} last />
      </SSection>

      {/* ── About ── */}
      <SSection title="About" theme={theme}>
        <SRow theme={theme} label="Version"
          right={<span style={{ fontFamily: "'Chakra Petch', monospace", fontSize: 13, fontWeight: 600, color: theme.faintText }}>1.0.0</span>} />
        <SRow theme={theme} label="Rate the app"
          right={
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M6 12L10 8 6 4" stroke={theme.faintText} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          } last />
      </SSection>

    </div>
  );
}

window.SettingsScreen = SettingsScreen;
