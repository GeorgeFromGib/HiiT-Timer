// SessionComplete — celebration screen shown when a HIIT session finishes.
// Same visual vocabulary as ThemedTimer / SessionsScreens: gradient bg,
// ghost surfaces, hairlines, Chakra Petch numbers, phase colour recap.

const { useState: useCState, useEffect: useCEffect } = React;

// default completed session (matches "Tabata Burnout")
const DONE_SESSION = {
  name: 'Tabata Burnout',
  intervals: [
    { type: 'warmup', dur: 45 }, { type: 'work', dur: 30 }, { type: 'rest', dur: 15 },
    { type: 'blast', dur: 30 }, { type: 'rest', dur: 15 }, { type: 'work', dur: 30 },
    { type: 'rest', dur: 15 }, { type: 'blast', dur: 30 }, { type: 'rest', dur: 15 },
    { type: 'cooldown', dur: 60 },
  ],
};

function cFmt(s) {
  s = Math.max(0, Math.round(s));
  const m = Math.floor(s / 60), sec = s % 60;
  return `${m}:${String(sec).padStart(2, '0')}`;
}

function CheckMark({ color, size = 64 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
      <path className="c-check" d="M10 25l9.5 9.5L38 15" stroke={color} strokeWidth="5"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function SessionComplete({ theme, session = DONE_SESSION }) {
  const total = session.intervals.reduce((a, b) => a + b.dur, 0);
  const workTime = session.intervals
    .filter(iv => iv.type === 'work' || iv.type === 'blast')
    .reduce((a, b) => a + b.dur, 0);
  const count = session.intervals.length;

  const phaseCol = (type) => (theme.phases ? theme.phases[type] : '#46a6ff');
  const intervals = session.intervals.map(iv => ({ ...iv, color: phaseCol(iv.type) }));

  const Stat = ({ label, value, sub, accent }) => (
    <div style={{
      flex: 1, background: theme.card, border: `1px solid ${theme.hairline}`,
      borderRadius: 16, padding: '14px 14px 13px',
      display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'center',
    }}>
      <span style={{
        fontFamily: "'Chakra Petch', monospace", fontWeight: 700, fontSize: 25,
        lineHeight: 1, color: accent || theme.text, fontVariantNumeric: 'tabular-nums',
      }}>{value}</span>
      <span style={{
        fontSize: 9.5, letterSpacing: '0.12em', textTransform: 'uppercase',
        fontWeight: 700, color: theme.faintText,
      }}>{label}</span>
    </div>
  );

  return (
    <div style={{
      width: '100%', height: '100%',
      background: `radial-gradient(130% 75% at 50% -8%, ${theme.accent}22 0%, ${theme.bg[1]} 40%, ${theme.bg[0]} 100%)`,
      display: 'flex', flexDirection: 'column',
      padding: '54px 22px 26px', boxSizing: 'border-box',
      fontFamily: "'Inter', sans-serif", color: theme.text, overflow: 'hidden', position: 'relative',
    }} className="cmplt">
      {/* confetti specks */}
      {[...Array(14)].map((_, i) => {
        const cols = ['warmup', 'work', 'blast', 'rest'].map(phaseCol);
        const c = cols[i % cols.length];
        const left = (i * 37 + 11) % 100;
        const delay = (i % 7) * 0.18;
        const dur = 2.6 + (i % 5) * 0.4;
        const sz = 5 + (i % 3) * 2;
        return (
          <span key={i} className="c-confetti" style={{
            position: 'absolute', top: -12, left: `${left}%`, width: sz, height: sz,
            borderRadius: i % 2 ? '50%' : 2, background: c,
            ['--cd']: `${dur}s`, ['--cdl']: `${delay}s`,
          }} />
        );
      })}

      {/* eyebrow */}
      <div className="c-rise c-eyebrow" style={{ textAlign: 'center', position: 'relative', zIndex: 2 }}>
        <span style={{
          fontSize: 11, letterSpacing: '0.24em', textTransform: 'uppercase',
          color: theme.accent, fontWeight: 800,
        }}>Workout Complete</span>
      </div>

      {/* hero ring + check */}
      <div style={{
        flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', margin: '14px 0 4px', zIndex: 2,
      }}>
        <div className="c-pop" style={{ position: 'relative', width: 188, height: 188 }}>
          <window.SegmentedRing size={188} stroke={12} intervals={intervals} elapsed={total} total={total} />
          <div style={{
            position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <div style={{
              width: 96, height: 96, borderRadius: '50%',
              background: `radial-gradient(120% 120% at 30% 25%, ${theme.accent}, ${theme.accent}cc 60%, ${theme.accent}99)`,
              boxShadow: `0 12px 34px ${theme.accent}66, inset 0 1px 2px rgba(255,255,255,0.5)`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <CheckMark color={theme.btnGlyph} size={58} />
            </div>
          </div>
        </div>
      </div>

      {/* headline */}
      <div className="c-rise" style={{ textAlign: 'center', marginTop: 6, zIndex: 2, ['--rd']: '0.1s' }}>
        <div style={{ fontSize: 30, fontWeight: 900, letterSpacing: '-0.02em', lineHeight: 1.05 }}>Crushed it!</div>
        <div style={{ fontSize: 13.5, fontWeight: 600, color: theme.subText, marginTop: 6 }}>
          You finished <span style={{ color: theme.text, fontWeight: 800 }}>{session.name}</span>
        </div>
      </div>

      {/* stats */}
      <div className="c-rise" style={{ display: 'flex', gap: 9, marginTop: 22, zIndex: 2, ['--rd']: '0.18s' }}>
        <Stat label="Total Time" value={cFmt(total)} accent={theme.accent} />
        <Stat label="Intervals" value={count} />
        <Stat label="Work Time" value={cFmt(workTime)} />
      </div>

      {/* phase recap */}
      <div className="c-rise" style={{ marginTop: 16, zIndex: 2, ['--rd']: '0.26s' }}>
        <div style={{
          fontSize: 10, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase',
          color: theme.faintText, marginBottom: 8, paddingLeft: 2,
        }}>Session Recap</div>
        <window.PhaseStrip intervals={session.intervals} theme={theme} height={10} radius={5} />
      </div>

      {/* actions */}
      <div style={{ marginTop: 'auto', paddingTop: 20, display: 'flex', flexDirection: 'column', gap: 10, zIndex: 2 }}>
        <button style={{
          appearance: 'none', cursor: 'pointer', width: '100%', padding: '14px 0',
          borderRadius: 16, border: 'none', background: theme.accent, color: theme.btnGlyph,
          fontSize: 14.5, fontWeight: 800, letterSpacing: '0.05em',
          boxShadow: `0 10px 26px ${theme.accent}55`,
        }}>DONE</button>
        <button style={{
          appearance: 'none', cursor: 'pointer', width: '100%', padding: '13px 0',
          borderRadius: 16, border: `1px solid ${theme.hairline}`, background: theme.ghostBg,
          color: theme.subText, fontSize: 13.5, fontWeight: 700, letterSpacing: '0.05em',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 9,
        }}>
          <svg width="16" height="16" viewBox="0 0 20 20" fill="none"><path d="M3 10a7 7 0 1 1 2.3 5.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/><path d="M3 5v4h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          REPEAT SESSION
        </button>
      </div>
    </div>
  );
}

// inject keyframes once
if (!document.getElementById('cmplt-kf')) {
  const st = document.createElement('style');
  st.id = 'cmplt-kf';
  st.textContent = `
    /* base = fully visible; confetti hidden unless motion is allowed */
    .cmplt .c-confetti { display: none; }
    @keyframes cDraw { from { stroke-dashoffset: 60; } to { stroke-dashoffset: 0; } }
    @keyframes cPop { 0% { transform: scale(0.7); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }
    @keyframes cRise { from { transform: translateY(12px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    @keyframes cFall { 0% { transform: translateY(0) rotate(0); opacity: 0; } 8% { opacity: 0.9; } 100% { transform: translateY(640px) rotate(420deg); opacity: 0; } }
    @media (prefers-reduced-motion: no-preference) {
      .cmplt .c-confetti { display: block; opacity: 0; animation: cFall var(--cd, 3s) var(--cdl, 0s) linear infinite; }
      .cmplt .c-rise { animation: cRise 0.5s var(--rd, 0s) ease both; }
      .cmplt .c-pop { animation: cPop 0.6s cubic-bezier(0.34,1.56,0.64,1) both; }
      .cmplt .c-check { stroke-dasharray: 60; animation: cDraw 0.55s 0.35s cubic-bezier(0.65,0,0.35,1) both; }
    }
  `;
  document.head.appendChild(st);
}

window.SessionComplete = SessionComplete;
