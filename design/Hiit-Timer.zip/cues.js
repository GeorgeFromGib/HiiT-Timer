// cues.js — tiny WebAudio synth for distinct per-phase audio language.
// Different timbre/pitch per phase + a tick for the 3-2-1 and a finish chord.

const Cues = (() => {
  let ctx = null;
  const ac = () => (ctx = ctx || new (window.AudioContext || window.webkitAudioContext)());

  function tone(freq, dur, { type = 'sine', gain = 0.18, when = 0 } = {}) {
    const c = ac();
    const t0 = c.currentTime + when;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(c.destination);
    o.start(t0); o.stop(t0 + dur + 0.02);
  }

  return {
    resume() { try { ac().resume(); } catch {} },
    tick() { tone(880, 0.09, { type: 'square', gain: 0.10 }); },
    // each phase gets its own voice
    phase(type) {
      switch (type) {
        case 'work':     tone(660, 0.22, { type: 'sawtooth', gain: 0.16 }); tone(990, 0.22, { type: 'sawtooth', gain: 0.08, when: 0.04 }); break;
        case 'blast':    tone(740, 0.16, { type: 'square', gain: 0.16 }); tone(1108, 0.16, { type: 'square', gain: 0.10, when: 0.08 }); tone(1480, 0.16, { type: 'square', gain: 0.06, when: 0.16 }); break;
        case 'rest':     tone(392, 0.30, { type: 'sine', gain: 0.16 }); break;
        case 'warmup':   tone(523, 0.26, { type: 'triangle', gain: 0.15 }); break;
        case 'cooldown': tone(440, 0.34, { type: 'sine', gain: 0.15 }); tone(330, 0.34, { type: 'sine', gain: 0.10, when: 0.05 }); break;
        default:         tone(523, 0.2, {});
      }
    },
    finish() {
      [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.5, { type: 'triangle', gain: 0.14, when: i * 0.12 }));
    },
  };
})();

window.Cues = Cues;
