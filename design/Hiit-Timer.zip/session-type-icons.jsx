// SessionTypeIcon — line icons for the four HIIT session types.
// Same vocabulary as PHASE_META's TIcon: 24×24 viewBox, fill:none,
// round caps/joins, ~2.2 stroke, single accent colour.

// type metadata — label + which session-type accent (from theme palette)
const SESSION_TYPES = [
  { key: 'standard', label: 'Standard', desc: 'Interval timer',     icon: 'standard', tint: 'accent' },
  { key: 'run',      label: 'Run',      desc: 'Outdoor / treadmill', icon: 'run',      tint: 'rest'   },
  { key: 'circuit',  label: 'Circuit',  desc: 'Strength stations',   icon: 'circuit',  tint: 'work'   },
  { key: 'spinning', label: 'Spinning', desc: 'Indoor cycling',      icon: 'spinning', tint: 'warmup' },
];

function SessionTypeIcon({ name, color = 'currentColor', size = 26, w = 2.2 }) {
  const p = { fill: 'none', stroke: color, strokeWidth: w, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const ic = {
    // Standard — stopwatch (mirrors the app icon's crown + face motif)
    standard: (
      <g {...p}>
        <circle cx="12" cy="14" r="7" />
        <path d="M9.7 3.2h4.6" />
        <path d="M12 3.4V7" />
        <path d="M18.4 7.6l1.3-1.3" />
        <path d="M12 14l3 1.8" />
        <path d="M12 14V10.2" />
      </g>
    ),
    // Run — running figure leaning into the stride
    run: (
      <g {...p}>
        <circle cx="15.5" cy="4.6" r="2.1" />
        <path d="M14.2 8.3 10 13.4l3.6 1.9.5 5" />
        <path d="M10 13.4 6.2 16.8 4 18.4" />
        <path d="M13.6 9.6l3.3 1.7 2.7-.6" />
        <path d="M16.9 11.3l-.4 3" />
      </g>
    ),
    // Circuit — dumbbell (strength stations)
    circuit: (
      <g {...p}>
        <path d="M3.2 9.5v5" />
        <path d="M6.4 7.2v9.6" />
        <path d="M6.4 12h11.2" />
        <path d="M17.6 7.2v9.6" />
        <path d="M20.8 9.5v5" />
      </g>
    ),
    // Spinning — bicycle (indoor cycling)
    spinning: (
      <g {...p}>
        <circle cx="6" cy="16.4" r="3.5" />
        <circle cx="18" cy="16.4" r="3.5" />
        <path d="M11 16.4 9 8.2M11 16.4 16 8.2M9 8.2h7M11 16.4H6M16 8.2l2 8.2" />
        <path d="M7.9 7.7h2.4" />
        <path d="M16 8.2V6.4M14.7 6.4h2.6" />
      </g>
    ),
  };
  return <svg width={size} height={size} viewBox="0 0 24 24">{ic[name]}</svg>;
}

// resolve a session-type tint from the active theme
function typeTint(theme, type) {
  if (type.tint === 'accent') return theme.accent;
  return (theme.phases || {})[type.tint] || theme.accent;
}

// ── Showcase: cards in the same surface vocabulary as the app ───────
function SessionTypesShowcase({ theme }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      background: `linear-gradient(165deg, ${theme.bg[1]} 0%, ${theme.bg[0]} 100%)`,
      display: 'flex', flexDirection: 'column',
      padding: '52px 22px 26px', boxSizing: 'border-box',
      fontFamily: "'Inter', sans-serif", color: theme.text, overflow: 'hidden',
    }}>
      {/* header */}
      <div style={{ marginBottom: 22 }}>
        <div style={{
          fontSize: 11, letterSpacing: '0.22em', textTransform: 'uppercase',
          color: theme.accent, fontWeight: 800,
        }}>New Session</div>
        <div style={{ fontSize: 26, fontWeight: 900, letterSpacing: '-0.02em', marginTop: 6 }}>
          Choose a type
        </div>
      </div>

      {/* 2×2 grid of type cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {SESSION_TYPES.map((t) => {
          const c = typeTint(theme, t);
          return (
            <div key={t.key} style={{
              background: theme.card, border: `1px solid ${theme.hairline}`,
              borderRadius: 20, padding: '18px 16px 16px',
              display: 'flex', flexDirection: 'column', gap: 14, position: 'relative', overflow: 'hidden',
            }}>
              {/* faint corner glow in the type colour */}
              <div style={{
                position: 'absolute', top: -28, right: -28, width: 88, height: 88,
                borderRadius: '50%', background: c, opacity: 0.16, filter: 'blur(6px)',
              }} />
              {/* icon chip */}
              <div style={{
                width: 52, height: 52, borderRadius: 15,
                background: `${c}1f`, border: `1px solid ${c}3a`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: c, position: 'relative', zIndex: 1,
              }}>
                <SessionTypeIcon name={t.icon} color={c} size={28} w={2.1} />
              </div>
              <div style={{ position: 'relative', zIndex: 1 }}>
                <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: '-0.01em' }}>{t.label}</div>
                <div style={{ fontSize: 12, fontWeight: 600, color: theme.faintText, marginTop: 2 }}>{t.desc}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* inline glyph row — how the icons read at list scale */}
      <div style={{
        marginTop: 'auto', display: 'flex', alignItems: 'center', justifyContent: 'space-around',
        background: theme.ghostBg, border: `1px solid ${theme.hairline}`,
        borderRadius: 16, padding: '14px 10px',
      }}>
        {SESSION_TYPES.map((t) => {
          const c = typeTint(theme, t);
          return (
            <div key={t.key} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 7 }}>
              <SessionTypeIcon name={t.icon} color={c} size={24} w={2.2} />
              <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: theme.faintText }}>{t.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.SESSION_TYPES = SESSION_TYPES;
window.SessionTypeIcon = SessionTypeIcon;
window.SessionTypesShowcase = SessionTypesShowcase;
