// HIIT timer — glanceability-first. Big phase WORD + state colour, whole-session
// timeline ("you are here"), next-up label, and a 3-2-1 transition cue.

const { useState, useEffect, useRef, useCallback } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#3ad6c6",
  "bg": ["#0b1d26", "#0e2832"],
  "sound": true,
  "ambientTint": true
}/*EDITMODE-END*/;

// ── per-phase visual + audio language ──────────────────────────
const PHASE = {
  warmup:   { label: 'WARM UP',  color: '#5fd38a', icon: 'sun' },
  work:     { label: 'WORK',     color: '#ff8a3d', icon: 'flame' },
  blast:    { label: 'ALL OUT',  color: '#ff5a5f', icon: 'bolt' },
  rest:     { label: 'RECOVER',  color: '#46a6ff', icon: 'pause' },
  cooldown: { label: 'COOL DOWN',color: '#5fd38a', icon: 'snow' },
};

const WORKOUT = [
  { type: 'warmup',   dur: 45 },
  { type: 'work',     dur: 30 },
  { type: 'rest',     dur: 15 },
  { type: 'blast',    dur: 30 },
  { type: 'rest',     dur: 15 },
  { type: 'work',     dur: 30 },
  { type: 'rest',     dur: 15 },
  { type: 'blast',    dur: 30 },
  { type: 'rest',     dur: 15 },
  { type: 'cooldown', dur: 60 },
];

const fmt = (s) => {
  s = Math.max(0, Math.ceil(s));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};

function PhaseIcon({ name, color, size = 26 }) {
  const p = { fill: 'none', stroke: color, strokeWidth: 2.2, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const ic = {
    sun:   <g {...p}><circle cx="12" cy="12" r="4.2"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M19.1 4.9l-1.8 1.8M6.7 17.3l-1.8 1.8"/></g>,
    flame: <path {...p} d="M12 2.5c3 4 6 5.5 6 10a6 6 0 0 1-12 0c0-2 1-3.4 2.4-4.6.2 1.6 1 2.4 2 2.6-1.2-3 .3-6.4 1.6-8z"/>,
    bolt:  <path {...p} d="M13 2 4 13h6l-1 9 9-12h-6l1-8z"/>,
    pause: <g {...p}><rect x="6" y="5" width="4" height="14" rx="1.5"/><rect x="14" y="5" width="4" height="14" rx="1.5"/></g>,
    snow:  <g {...p}><path d="M12 2v20M3.5 7l17 10M20.5 7l-17 10"/><path d="M12 6l-2.5-2.5M12 6l2.5-2.5M12 18l-2.5 2.5M12 18l2.5 2.5"/></g>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24">{ic[name]}</svg>;
}

function PlayButton({ running, accent, onClick }) {
  return (
    <button onClick={onClick} aria-label={running ? 'Pause' : 'Start'} style={{
      appearance: 'none', border: 'none', cursor: 'pointer',
      width: 80, height: 80, borderRadius: '50%',
      background: `radial-gradient(120% 120% at 30% 25%, ${accent}, ${accent}cc 60%, ${accent}99)`,
      boxShadow: `0 12px 32px ${accent}55, inset 0 1px 1px rgba(255,255,255,0.45)`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: '#06131a', transition: 'transform 0.12s ease',
    }}
    onMouseDown={(e) => e.currentTarget.style.transform = 'scale(0.93)'}
    onMouseUp={(e) => e.currentTarget.style.transform = 'scale(1)'}
    onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}>
      {running
        ? <svg width="28" height="30" viewBox="0 0 28 30"><rect x="3" y="2" width="8" height="26" rx="2.6" fill="currentColor"/><rect x="17" y="2" width="8" height="26" rx="2.6" fill="currentColor"/></svg>
        : <svg width="28" height="30" viewBox="0 0 28 30"><path d="M5 3 L25 15 L5 27 Z" fill="currentColor" stroke="currentColor" strokeWidth="3.5" strokeLinejoin="round"/></svg>}
    </button>
  );
}

function GhostBtn({ children, onClick, label }) {
  return (
    <button aria-label={label} onClick={onClick} style={{
      appearance: 'none', cursor: 'pointer', width: 58, height: 58, borderRadius: '50%',
      background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.09)',
      color: 'rgba(255,255,255,0.72)', display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>{children}</button>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const total = WORKOUT.reduce((a, b) => a + b.dur, 0);
  const intervals = WORKOUT.map((iv) => ({ ...iv, color: PHASE[iv.type].color }));

  const saved = (() => { try { return JSON.parse(localStorage.getItem('hiit-pos') || 'null'); } catch { return null; } })();
  const [elapsed, setElapsed] = useState(saved?.elapsed ?? 0);
  const [running, setRunning] = useState(false);
  const last = useRef(null);
  const prevIdx = useRef(null);
  const prevTick = useRef(null);

  useEffect(() => { try { localStorage.setItem('hiit-pos', JSON.stringify({ elapsed })); } catch {} }, [elapsed]);

  useEffect(() => {
    if (!running) { last.current = null; return; }
    last.current = Date.now();
    const id = setInterval(() => {
      const now = Date.now();
      const dt = (now - last.current) / 1000;
      last.current = now;
      setElapsed((e) => {
        const ne = e + dt;
        if (ne >= total) { setRunning(false); return total; }
        return ne;
      });
    }, 80);
    return () => clearInterval(id);
  }, [running, total]);

  // derive current interval
  let acc = 0, idx = 0, intoPhase = 0;
  for (let i = 0; i < WORKOUT.length; i++) {
    if (elapsed < acc + WORKOUT[i].dur || i === WORKOUT.length - 1) { idx = i; intoPhase = elapsed - acc; break; }
    acc += WORKOUT[i].dur;
  }
  const cur = WORKOUT[idx];
  const info = PHASE[cur.type];
  const phaseRemaining = cur.dur - intoPhase;
  const next = WORKOUT[idx + 1];
  const nextInfo = next ? PHASE[next.type] : null;
  const remaining = total - elapsed;
  const isDone = elapsed >= total;

  // 3-2-1 cue window
  const cueN = (running && !isDone && phaseRemaining <= 3.4 && phaseRemaining > 0.05) ? Math.ceil(phaseRemaining) : 0;

  // ── audio cues (distinct per phase + tick + finish) ──
  useEffect(() => {
    if (!t.sound || !running) return;
    if (prevIdx.current === null) { prevIdx.current = idx; return; }
    if (idx !== prevIdx.current) { Cues.phase(cur.type); prevIdx.current = idx; }
  }, [idx, running, t.sound, cur.type]);

  useEffect(() => {
    if (!t.sound || !running) return;
    if (cueN && cueN !== prevTick.current) { Cues.tick(); prevTick.current = cueN; }
    if (!cueN) prevTick.current = null;
  }, [cueN, running, t.sound]);

  useEffect(() => { if (isDone && t.sound) Cues.finish(); }, [isDone, t.sound]);

  const reset = () => { setRunning(false); setElapsed(0); prevIdx.current = null; };
  const skip = () => { setElapsed(Math.min(total, acc + cur.dur)); };
  const togglePlay = () => { Cues.resume(); if (isDone) { setElapsed(0); prevIdx.current = null; } setRunning((r) => !r); };

  const tint = t.ambientTint ? info.color : t.accent;

  return (
    <div style={{
      width: '100%', height: '100%',
      background: `radial-gradient(130% 80% at 50% -10%, ${tint}24 0%, ${t.bg[1]} 38%, ${t.bg[0]} 100%)`,
      transition: 'background 0.6s ease',
      display: 'flex', flexDirection: 'column',
      padding: '58px 22px 28px', boxSizing: 'border-box',
      fontFamily: "'Inter', -apple-system, system-ui, sans-serif",
      color: '#eef6f7', position: 'relative', overflow: 'hidden',
    }}>
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <span style={{ fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', fontWeight: 700, whiteSpace: 'nowrap' }}>Interval Session</span>
          <span style={{ fontSize: 19, fontWeight: 700, letterSpacing: '-0.01em' }}>Tabata Burnout</span>
        </div>
        <button aria-label="Close" style={{
          appearance: 'none', cursor: 'pointer', width: 38, height: 38, borderRadius: '50%',
          background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.09)',
          color: 'rgba(255,255,255,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <svg width="15" height="15" viewBox="0 0 15 15"><path d="M2 2l11 11M13 2L2 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
        </button>
      </div>

      {/* ── GLANCEABLE HERO ── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        {/* phase word + icon */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 4 }}>
          <span style={{
            display: 'inline-flex', width: 46, height: 46, borderRadius: 14,
            alignItems: 'center', justifyContent: 'center',
            background: `${info.color}22`, border: `1.5px solid ${info.color}55`,
          }}><PhaseIcon name={info.icon} color={info.color} size={26} /></span>
          <span style={{
            fontSize: 50, fontWeight: 900, letterSpacing: '0.02em', lineHeight: 0.95,
            color: info.color, textShadow: `0 0 30px ${info.color}55`,
          }}>{isDone ? 'DONE' : info.label}</span>
        </div>

        {/* giant countdown */}
        <span style={{
          fontFamily: "'Chakra Petch', monospace", fontWeight: 700,
          fontSize: 110, lineHeight: 1, letterSpacing: '0',
          fontVariantNumeric: 'tabular-nums', color: '#f4fbfb',
          textShadow: `0 0 36px ${info.color}3a`,
        }}>{isDone ? fmt(0) : fmt(phaseRemaining)}</span>

        {/* interval counter */}
        <span style={{ fontSize: 15, fontWeight: 700, color: 'rgba(255,255,255,0.45)', letterSpacing: '0.08em', marginTop: 2 }}>
          INTERVAL <span style={{ color: info.color }}>{idx + 1}</span> OF {WORKOUT.length}
        </span>

        {/* phase-progress bar — same thickness as session timeline, depletes with time left in this zone */}
        <div style={{ width: '100%', maxWidth: 260, height: 26, borderRadius: 7, background: 'rgba(255,255,255,0.08)', overflow: 'hidden', marginTop: 20, display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ height: '100%', width: `${isDone ? 0 : Math.max(0, (phaseRemaining / cur.dur) * 100)}%`, background: info.color, borderRadius: 7, boxShadow: `0 0 14px ${info.color}99`, transition: 'width 0.2s linear' }} />
        </div>

        {/* 3-2-1 cue overlay */}
        {cueN > 0 && (
          <div key={cueN} style={{
            position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', pointerEvents: 'none',
            animation: 'cuePulse 0.6s ease-out',
          }}>
            <div style={{
              fontFamily: "'Chakra Petch', monospace", fontWeight: 700, fontSize: 230,
              color: nextInfo ? nextInfo.color : info.color, lineHeight: 1,
              textShadow: `0 0 60px ${(nextInfo || info).color}`,
            }}>{cueN}</div>
            {nextInfo && <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: '0.16em', color: nextInfo.color, marginTop: -10 }}>{nextInfo.label} NEXT</div>}
          </div>
        )}
      </div>

      {/* NEXT UP */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        padding: '10px 0', marginBottom: 4,
      }}>
        <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: '0.14em', color: 'rgba(255,255,255,0.38)' }}>NEXT</span>
        <svg width="16" height="14" viewBox="0 0 16 14" style={{ color: 'rgba(255,255,255,0.35)' }}><path d="M1 7h12M9 2l5 5-5 5" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
        {nextInfo ? (
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
            <PhaseIcon name={nextInfo.icon} color={nextInfo.color} size={17} />
            <span style={{ fontSize: 15, fontWeight: 800, letterSpacing: '0.06em', color: nextInfo.color }}>{nextInfo.label}</span>
            <span style={{ fontSize: 15, fontWeight: 700, color: 'rgba(255,255,255,0.55)', fontFamily: "'Chakra Petch', monospace" }}>{fmt(next.dur)}</span>
          </div>
        ) : (
          <span style={{ fontSize: 15, fontWeight: 800, letterSpacing: '0.06em', color: info.color }}>FINISH LINE</span>
        )}
      </div>

      {/* SESSION TIMELINE — you are here */}
      <SessionTimeline intervals={intervals} elapsed={elapsed} total={total} currentIdx={idx} />

      {/* compact stats */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 16, marginBottom: 6 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <span style={{ fontSize: 10.5, letterSpacing: '0.13em', textTransform: 'uppercase', fontWeight: 700, color: 'rgba(255,255,255,0.4)' }}>Remaining</span>
          <span style={{ fontFamily: "'Chakra Petch', monospace", fontSize: 24, fontWeight: 600, color: '#eef6f7', fontVariantNumeric: 'tabular-nums' }}>{fmt(remaining)}</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'flex-end' }}>
          <span style={{ fontSize: 10.5, letterSpacing: '0.13em', textTransform: 'uppercase', fontWeight: 700, color: t.accent }}>Completed</span>
          <span style={{ fontFamily: "'Chakra Petch', monospace", fontSize: 24, fontWeight: 600, color: '#eef6f7', fontVariantNumeric: 'tabular-nums' }}>{fmt(elapsed)}</span>
        </div>
      </div>

      {/* controls */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 26, marginTop: 8 }}>
        <GhostBtn label="Reset" onClick={reset}>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M3 10a7 7 0 1 1 2.3 5.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/><path d="M3 5v4h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </GhostBtn>
        <PlayButton running={running} accent={t.accent} onClick={togglePlay} />
        <GhostBtn label="Skip" onClick={skip}>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M4 4l9 6-9 6V4z" fill="currentColor"/><rect x="15" y="4" width="2.5" height="12" rx="1.2" fill="currentColor"/></svg>
        </GhostBtn>
      </div>

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakColor label="Button accent" value={t.accent}
          options={['#3ad6c6', '#ff8a3d', '#5fd38a', '#a78bfa', '#46a6ff']}
          onChange={(v) => setTweak('accent', v)} />
        <TweakColor label="Background" value={t.bg}
          options={[['#0b1d26', '#0e2832'], ['#13111c', '#1c1830'], ['#0a0a0c', '#16181d']]}
          onChange={(v) => setTweak('bg', v)} />
        <TweakSection label="Glanceability" />
        <TweakToggle label="Ambient phase tint" value={t.ambientTint} onChange={(v) => setTweak('ambientTint', v)} />
        <TweakToggle label="Audio cues" value={t.sound} onChange={(v) => setTweak('sound', v)} />
      </TweaksPanel>

      <style>{`@keyframes cuePulse{0%{opacity:0;transform:scale(0.6)}30%{opacity:1;transform:scale(1.05)}100%{opacity:0;transform:scale(1.25)}}`}</style>
    </div>
  );
}

window.HiitApp = App;
